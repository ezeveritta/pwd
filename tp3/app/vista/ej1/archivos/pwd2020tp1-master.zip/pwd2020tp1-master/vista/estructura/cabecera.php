<html>
<title><?PHP $Titulo?></title>
<header>


</header>
</head>
<body>
<div style="height: 80px; width: 100%; border: 2px solid red; border-radius: 5px;"> <h1>Este es la cabecera</h1> </div>
   
<?php  
include_once("../../configuracion.php");
include_once("../estructura/lateral.php");
?>


