<?php

$GLOBALS['ROOT'] =$_SERVER['DOCUMENT_ROOT'] ."/pwd2020tp1/";

include_once("../../utiles/funciones.php");



?>